package us.codecraft.tinyioc;

/**
 * @author yihua.huang@dianping.com
 */
public class HelloWorldService {

    public void helloWorld(){
        System.out.println("Hello World!");
    }
}
