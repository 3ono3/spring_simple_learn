tiny-IoC
=====

步骤：

## 1.step1-最基本的容器
*step-1-container-register-and-get*

单纯的map，有get和put bean的功能


## 2.step2-inject
*step-2-container-register-and-get*

1. 抽象beanfactory
2. 将bean初始化放入beanfactory
	
3
. xml